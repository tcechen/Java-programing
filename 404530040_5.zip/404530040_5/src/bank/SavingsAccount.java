package bank;

import java.util.ArrayList;

public class SavingsAccount extends BankAccount {
	
	private double interestRate=10;
	private double minBalance;
	ArrayList<Double>saveTransList= new ArrayList<Double>();
	
	 /**
	  *inheit from bankAccount constructor
	  */
	public SavingsAccount(int accountNumber, double initialBalance){
		super(accountNumber,initialBalance);
	}
	
	public SavingsAccount(int accountNumber, double initialBalance, double interestRate){
		super(accountNumber,initialBalance);
		this.interestRate=interestRate;
	}
	
	/**
	 *calculate the interest and deposit
	 */
	void addInterset(){
		minBalance=getBalance();
		interestRate=minBalance*interestRate;
		deposit(interestRate);
	}
	
}
