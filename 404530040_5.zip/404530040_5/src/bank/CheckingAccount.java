package bank;

public class CheckingAccount extends BankAccount {
	 double fee=2;
	 int withdrawAmount=0;
	 public CheckingAccount(int AccountNumber,double initialBalance) {
		super(AccountNumber,initialBalance);
	}
	 
	 /**
	 *inherit from BankAccount
	 */
	void deposit(double amount) {
		
		super.deposit(amount);
	}
	
	/**
	 *inherit from BankAccount and count withdraw amount
	 */
	void withdraw(double amount) {
		
		super.withdraw(amount);
		withdrawAmount++;
	}
	
	/**
	 *check if the withdrawAmount greater than 3, and if fees > balance withdraw the balance
	 */
	void deductFees(){
		if(withdrawAmount>3){
			returnBalance(getBalance()-2);
		}
		if(fee>getBalance()){
			withdraw(getBalance());
		}
	}
}
