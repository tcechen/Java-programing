
public interface GradeAnalyzerInterface {
		Boolean isValidGrade(double grade);
		void addGrade(double grade);
		void analyzeGrades();
		String toString();
		
}
