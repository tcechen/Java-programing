/**
* This program is to calculate the Easter Sunday in the specified year
*/
import java.util.*;


public class EasterTester {

	public static void main(String[] args) {
		//HW requirements
		System.out.println(Easter.CalculateEaster(2001));
		System.out.println(Easter.CalculateEaster(2012));
		
		boolean flag=true;//if flag = false end of output
		
		//users input
		while(flag!=false){
		System.out.println("Please enter a year to calculate Easter Sunday.");
		Scanner sc =new Scanner(System.in);
		
		//check if user enter the number
		while(!sc.hasNextInt()){
			System.out.println("Please enter a year.(Do not enter any letter)");
			sc.next();			
		}
		int year=sc.nextInt();
		
		System.out.println(Easter.CalculateEaster(year));
		
		System.out.println("Continuous?(Yes/No)");
		String input=sc.next();
		
		
		if(input.equals("no")||input.equals("No")){
			flag=false;					
			sc.close();
		}
		
		}
		System.out.println("End of output!");
		
		
		
		
	}

}
