package CCUCinema;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Set;

import javax.swing.*;

import org.omg.CORBA.PUBLIC_MEMBER;

public class CinemaGUI implements ActionListener{
	private JFrame frame;
		
	public CinemaGUI(){
			frame=new JFrame();
			
		}
	void run(){
		String[] price={"10","20","30","40","50"};
		
		JPanel Panel1 = new JPanel();//set panel(small)
		JPanel mainPanel=new JPanel(new BorderLayout());//main panel(big)
		JComboBox combobox=new JComboBox(price);
		
		frame.setTitle("CCU★Cinema Seat reservation");
		frame.setSize(700,550);		
		mainPanel.setBounds(10, 10, 650, 500);
	
		//add combobox to the north of the screen
		mainPanel.add(combobox,BorderLayout.NORTH);
		mainPanel.add(Panel1);
		frame.add(mainPanel);
		
		//set the layout for buttons
		Panel1.setLayout(new GridLayout(9, 10, 3, 3));
		
		//name for all of the button
		for(int i=1;i<=90;i++){
			String myButtonName="A"+i;
			if(i>10&&i<=20){			
				myButtonName="B"+(i-10);
			}
			if(i>20&&i<=30){
				myButtonName="C"+(i-20);
			}
			if(i>30&&i<=40){
				myButtonName="D"+(i-30);
			}
			if(i>40&&i<=50){
				myButtonName="E"+(i-40);
			}
			if(i>50&&i<=60){
				myButtonName="F"+(i-50);
			}
			if(i>60&&i<=70){
				myButtonName="G"+(i-60);
			}
			if(i>70&&i<=80){
				myButtonName="H"+(i-70);
			}
			if(i>80&&i<=90){
				myButtonName="I"+(i-80);
			}
			//new all the button(不確定可行 要試試), setActionCommand->辨別名稱ex.A1,B1
			//用string去存
			Button buttonName=new Button(myButtonName);
			Panel1.add(buttonName);
			buttonName.setActionCommand(myButtonName);
					
		}	
		
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
		 
		
		//Combobox ActionListener
		combobox.addActionListener(new ActionListener() {
		
			public void actionPerformed(ActionEvent e) {
				Object selectPrice=combobox.getSelectedItem();
				System.out.println(selectPrice);
			}
		});
		
		//call for the window adapter (可以關閉視窗)
		 frame.addWindowListener(new WindowAdapter() { 
             public void windowClosing(WindowEvent e) 
              {System.exit(0);} }); 
	}
	
	//button click
	public void actionPerformed(ActionEvent e){
		String cmd=e.getActionCommand();
		//之後就呼叫元媛程式 有錯再修改
	}
	
	}
	


